# -*- coding: utf-8 -*-
{
    'name': "UpoBeer",
    'summary': """Administración de UpoBeer""",
    'description': """Administración de pedidos,clientes,cervezas...""",
    'author': "Grupo 13",
    'category': 'UpoBeer',
    'version': '0.1',
    'depends': ['base'],
    'data': ['views/cliente_view.xml','views/cerveza_view.xml','views/pedido_view.xml'],
    'demo': [ ],
    'application': True,
}